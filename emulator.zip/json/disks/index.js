disk_index = [
  
  {
     "filename": "json/disks/dos33master.json",
     "name": "DOS 3.3 Master",
     "category": "System"
  },
  {
     "filename": "json/disks/dos33master2.json",
     "name": "DOS 3.3 Master 2",
     "category": "System"
  },
  {
     "filename": "json/disks/dos33sample.json",
     "name": "DOS 3.3 Sample",
     "category": "System"
  },
  {
     "filename": "json/disks/prodos.json",
     "name": "ProDOS",
     "category": "System"
  },
  {
     "filename": "json/disks/prodos8.json",
     "e": true,
     "name": "ProDOS 8",
     "category": "System"
  }
  
];